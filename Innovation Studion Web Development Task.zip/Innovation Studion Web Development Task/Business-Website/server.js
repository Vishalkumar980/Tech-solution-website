const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/techsolutions_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('🎉 MongoDB Connected to TechSolutions Database!');
  console.log('📊 Database: techsolutions_db');
})
.catch((error) => {
  console.log('❌ MongoDB Connection Error:', error.message);
});

// Enhanced Contact Schema with Professional Fields
const contactSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String },
  company: { type: String },
  service: { type: String },
  message: { type: String, required: true },
  budget: { type: String },
  date: { type: Date, default: Date.now },
  status: { type: String, default: 'new' }
});

const Contact = mongoose.model('Contact', contactSchema);

// Professional Services Schema
const serviceSchema = new mongoose.Schema({
  title: String,
  description: String,
  icon: String,
  price: String,
  features: [String]
});

const Service = mongoose.model('Service', serviceSchema);

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/about', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

app.get('/services', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'services.html'));
});

app.get('/gallery', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'gallery.html'));
});

app.get('/contact', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'contact.html'));
});

// Enhanced API Routes
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, company, service, message, budget } = req.body;
    
    console.log('📧 New Professional Contact:', { name, email, company });
    
    // Validation
    if (!name || !email || !message) {
      return res.status(400).json({ 
        success: false, 
        message: 'Name, email, and message are required' 
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Please enter a valid email address' 
      });
    }
    
    const newContact = new Contact({ 
      name, email, phone, company, service, message, budget 
    });
    await newContact.save();
    
    res.status(201).json({ 
      success: true, 
      message: 'Thank you! We have received your inquiry and will contact you within 24 hours.',
      contactId: newContact._id
    });
  } catch (error) {
    console.error('Error saving contact:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Server error. Please try again later.' 
    });
  }
});

// Professional Admin Routes
app.get('/admin/contacts', async (req, res) => {
  try {
    const contacts = await Contact.find().sort({ date: -1 });
    res.json({ 
      success: true, 
      data: contacts, 
      count: contacts.length,
      business: 'TechSolutions Karachi'
    });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch contacts' });
  }
});

// Analytics endpoint
app.get('/admin/analytics', async (req, res) => {
  try {
    const totalContacts = await Contact.countDocuments();
    const newContacts = await Contact.countDocuments({ status: 'new' });
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayContacts = await Contact.countDocuments({ date: { $gte: today } });
    
    res.json({
      success: true,
      analytics: {
        totalContacts,
        newContacts,
        todayContacts,
        business: 'TechSolutions'
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch analytics' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 TechSolutions Server running on http://localhost:${PORT}`);
  console.log(`💼 Business: TechSolutions Karachi`);
  console.log(`📞 Support: +92 03177124118`);
});