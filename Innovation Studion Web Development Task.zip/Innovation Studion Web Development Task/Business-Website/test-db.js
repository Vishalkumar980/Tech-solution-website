const { MongoClient } = require('mongodb');

async function testConnection() {
  console.log('🔍 ===== MONGODB CONNECTION TEST =====');
  console.log('📡 Testing connection to: mongodb://localhost:27017');
  console.log('⏳ Please wait...\n');
  
  const uri = 'mongodb://localhost:27017';
  const client = new MongoClient(uri);

  try {
    // Try to connect with 10 second timeout
    await Promise.race([
      client.connect(),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('⏰ Connection timeout after 10 seconds')), 10000)
      )
    ]);
    
    console.log('✅ SUCCESS: Connected to MongoDB Server!');
    console.log('📍 Connection: mongodb://localhost:27017');
    
    // Test if we can list databases
    console.log('\n📊 Testing database access...');
    const adminDb = client.db().admin();
    const databases = await adminDb.listDatabases();
    
    console.log('✅ Database access successful!');
    console.log('📁 Available databases:');
    databases.databases.forEach(db => {
      console.log(`   - ${db.name} (Size: ${(db.sizeOnDisk / 1024 / 1024).toFixed(2)} MB)`);
    });
    
    // Test creating our business_website database
    console.log('\n🎯 Testing business_website database...');
    const ourDb = client.db('business_website');
    const collections = await ourDb.listCollections().toArray();
    
    console.log(`📂 Collections in business_website: ${collections.length}`);
    collections.forEach(collection => {
      console.log(`   - ${collection.name}`);
    });
    
    if (collections.length === 0) {
      console.log('💡 No collections found (this is normal for new database)');
    }
    
    console.log('\n🎉 ALL TESTS PASSED! MongoDB is working perfectly!');
    console.log('🚀 You can now use the original server.js with MongoDB');
    
  } catch (error) {
    console.log('\n❌ CONNECTION FAILED:');
    console.log('Error:', error.message);
    
    console.log('\n🔧 TROUBLESHOOTING STEPS:');
    console.log('1. Make sure MongoDB service is running');
    console.log('2. Check if port 27017 is not blocked');
    console.log('3. Try using 127.0.0.1 instead of localhost');
    console.log('4. Restart MongoDB service');
    
    console.log('\n💡 QUICK FIX: Try this connection string instead:');
    console.log('   mongodb://127.0.0.1:27017/business_website');
    
  } finally {
    await client.close();
    console.log('\n🔚 Test completed.');
  }
}

// Run the test
testConnection();